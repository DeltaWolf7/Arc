<div class="well">
<p class="lead">Synopsis</p>
<p>This section will improve your ??</p>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-body">
            </div>
            </div>
        </div>
    </div>
