<?php

system\Helper::arcAddMenuItem("Erudio", "fa-book", false, null, "Applications");