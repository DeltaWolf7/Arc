<?php

system\Helper::arcAddMenuItem("Erudio Manager", "fa-book", false, null, "Administration");