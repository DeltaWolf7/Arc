<?php

system\Helper::arcAddMenuItem("Question Editor", "fa-question", false, null, "Administration");
