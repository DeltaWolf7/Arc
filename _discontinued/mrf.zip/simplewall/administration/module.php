<?php

system\Helper::arcAddMenuItem("Wall Manager", "fa-bars", false, null, "Administration");