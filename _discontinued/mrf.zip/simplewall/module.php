<?php

system\Helper::arcAddMenuItem("The Wall", "fa-bars", false, null, "Applications");