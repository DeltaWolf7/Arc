<?php

system\Helper::arcAddMenuItem("Skype Booking Manager", "fa-skype", false, system\Helper::arcGetPath() . "skype/administration/manage", "Administration");