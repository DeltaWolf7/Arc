<?php
    system\Helper::arcAddHeader("css", system\Helper::arcGetTemplatePath() . "css/styles.css");
    system\Helper::arcAddHeader("css", system\Helper::arcGetTemplatePath() . "css/custom.css");
    system\Helper::arcAddHeader("css", "http://fonts.googleapis.com/css?family=Open+Sans:400,800,700,600,300");
    system\Helper::arcAddHeader("favicon", system\Helper::arcGetTemplatePath() . "favicon.png");