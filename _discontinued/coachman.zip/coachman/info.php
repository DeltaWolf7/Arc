<?php

$module_info["name"] = "Coach Manager";
$module_info["description"] = "Coach Manager for Arc";
$module_info["version"] = "0.0.0.1";
$module_info["author"] = "Craig Longford";
$module_info["email"] = "deltawolf7@gmail.com";
$module_info["www"] = "http://www.deltasblog.co.uk";

arcAddMenuItem("Coach Manager", "fa-bus", false, null, "Applications");

?>

