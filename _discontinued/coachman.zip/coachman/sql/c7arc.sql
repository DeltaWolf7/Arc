-- phpMyAdmin SQL Dump
-- version 4.2.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2015 at 11:20 AM
-- Server version: 5.5.40-0ubuntu1
-- PHP Version: 5.5.12-2ubuntu4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `c7arc`
--

-- --------------------------------------------------------

--
-- Table structure for table `coachman_bookings`
--

CREATE TABLE IF NOT EXISTS `coachman_bookings` (
`id` int(11) NOT NULL,
  `reference` varchar(10) NOT NULL,
  `journeydate` date NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `company` varchar(50) NOT NULL,
  `orderdate` date NOT NULL,
  `coachsize` int(11) NOT NULL,
  `departureaddress` text NOT NULL,
  `arrivaltime` time NOT NULL,
  `departuretime` time NOT NULL,
  `destination` text NOT NULL,
  `returndate` date NOT NULL,
  `returnplace` varchar(100) NOT NULL,
  `returndropoff` text NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `deposit` decimal(10,2) NOT NULL,
  `returntime` time NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `coachman_bookings`
--

INSERT INTO `coachman_bookings` (`id`, `reference`, `journeydate`, `customername`, `customerid`, `address`, `email`, `phone`, `mobile`, `company`, `orderdate`, `coachsize`, `departureaddress`, `arrivaltime`, `departuretime`, `destination`, `returndate`, `returnplace`, `returndropoff`, `cost`, `deposit`, `returntime`) VALUES
(1, 'TEST', '2014-11-01', 'Mr Test Customer', 1, 'Some address, some road', 'Email@emailaddress.com', '0800801', '808080808080', 'Test Co2', '2014-11-02', 6, 'Anywhere', '04:00:00', '04:00:00', 'Anywhere', '2014-11-03', 'Anywhere2', 'Any town drop off', 50.00, 10.00, '02:00:00'),
(7, '', '2014-11-21', '', 0, '', '', '', '', '', '2014-11-21', 6, '', '03:03:49', '03:03:49', '', '2014-11-21', '', '', 0.00, 0.00, '03:03:49');

-- --------------------------------------------------------

--
-- Table structure for table `coachman_customers`
--

CREATE TABLE IF NOT EXISTS `coachman_customers` (
`id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `company` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `coachman_customers`
--

INSERT INTO `coachman_customers` (`id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `company`) VALUES
(1, 'Test', 'Customer', 'test@test.com', '0800801801', '0777777777', 'Test Co');

-- --------------------------------------------------------

--
-- Table structure for table `coachman_drivers`
--

CREATE TABLE IF NOT EXISTS `coachman_drivers` (
`id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `costperhour` decimal(18,2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `coachman_drivers`
--

INSERT INTO `coachman_drivers` (`id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `costperhour`) VALUES
(2, 'Adam', 'Tester', 'adam@tester.com', '0800', '08088888', 10.00),
(3, 'Bob', 'Hope', 'email@address.com', '0000000000', '', 7.50);

-- --------------------------------------------------------

--
-- Table structure for table `coachman_vehicles`
--

CREATE TABLE IF NOT EXISTS `coachman_vehicles` (
`id` int(11) NOT NULL,
  `regno` varchar(10) NOT NULL,
  `seats` int(11) NOT NULL,
  `typeid` int(11) NOT NULL,
  `fuelcostpermile` decimal(18,2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `coachman_vehicles`
--

INSERT INTO `coachman_vehicles` (`id`, `regno`, `seats`, `typeid`, `fuelcostpermile`) VALUES
(8, 'JIW3694', 51, 1, 9.00),
(9, 'SEZ 4315', 69, 1, 0.90);

-- --------------------------------------------------------

--
-- Table structure for table `coachman_vehicletypes`
--

CREATE TABLE IF NOT EXISTS `coachman_vehicletypes` (
`id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `coachman_vehicletypes`
--

INSERT INTO `coachman_vehicletypes` (`id`, `name`) VALUES
(1, 'Test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coachman_bookings`
--
ALTER TABLE `coachman_bookings`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coachman_customers`
--
ALTER TABLE `coachman_customers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coachman_drivers`
--
ALTER TABLE `coachman_drivers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coachman_vehicles`
--
ALTER TABLE `coachman_vehicles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coachman_vehicletypes`
--
ALTER TABLE `coachman_vehicletypes`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coachman_bookings`
--
ALTER TABLE `coachman_bookings`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `coachman_customers`
--
ALTER TABLE `coachman_customers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `coachman_drivers`
--
ALTER TABLE `coachman_drivers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `coachman_vehicles`
--
ALTER TABLE `coachman_vehicles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `coachman_vehicletypes`
--
ALTER TABLE `coachman_vehicletypes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
